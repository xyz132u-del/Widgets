package com.maddy.widgets

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Build
import android.widget.RemoteViews
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.net.URL

object BatteryData {
    fun values(c: Context): Triple<Int, Boolean, Int> {
        val i = c.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (scale > 0) (level * 100 / scale) else 0
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugged = i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL || plugged != 0
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10
        return Triple(pct, charging, temp)
    }
}

abstract class BaseWidget : AppWidgetProvider() {
    abstract fun render(c: Context, id: Int, manager: AppWidgetManager)
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { ids.forEach { render(c, it, m) } }
    override fun onReceive(c: Context, i: Intent) { super.onReceive(c, i); if (i.action == Intent.ACTION_POWER_CONNECTED || i.action == Intent.ACTION_POWER_DISCONNECTED) { val m = AppWidgetManager.getInstance(c); m.getAppWidgetIds(android.content.ComponentName(c, javaClass)).forEach { render(c, it, m) } } }
}
class BatteryGridWidget : BaseWidget() {
    override fun render(c: Context, id: Int, m: AppWidgetManager) { val (p, ch, t) = BatteryData.values(c); val v = RemoteViews(c.packageName, R.layout.widget_battery_grid); v.setTextViewText(R.id.phone_pct, "$p"); v.setTextViewText(R.id.watch_pct, "—"); v.setTextViewText(R.id.earbuds_pct, "—"); v.setTextViewText(R.id.other_pct, "—"); v.setTextViewText(R.id.grid_caption, if (ch) "Charging" else "Battery"); m.updateAppWidget(id, v) }
}
class BatteryBarWidget : BaseWidget() {
    override fun render(c: Context, id: Int, m: AppWidgetManager) { val (p, ch, _) = BatteryData.values(c); val v = RemoteViews(c.packageName, R.layout.widget_battery_bar); v.setTextViewText(R.id.bar_pct, "$p%"); v.setProgressBar(R.id.bar_progress, 100, p, false); v.setTextViewText(R.id.bar_state, if (ch) "⚡ Charging" else "Not charging"); m.updateAppWidget(id, v) }
}
class ChargingInfoWidget : BaseWidget() {
    override fun render(c: Context, id: Int, m: AppWidgetManager) { val (p, ch, _) = BatteryData.values(c); val v = RemoteViews(c.packageName, R.layout.widget_charging_info); v.setTextViewText(R.id.info_pct, "$p%"); v.setTextViewText(R.id.info_state, if (ch) "Charging" else "Not charging"); v.setTextViewText(R.id.info_eta, if (ch && p < 100) "Time until full: estimating unavailable" else if (p == 100) "Fully charged" else "Connect charger to see charging status"); v.setProgressBar(R.id.info_progress, 100, p, false); m.updateAppWidget(id, v) }
}
class DateWidget : BaseWidget() {
    override fun render(c: Context, id: Int, m: AppWidgetManager) { val now = java.util.Calendar.getInstance(); val v = RemoteViews(c.packageName, R.layout.widget_date); v.setTextViewText(R.id.date_num, now.get(java.util.Calendar.DAY_OF_MONTH).toString()); v.setTextViewText(R.id.date_month, java.text.SimpleDateFormat("MMM", java.util.Locale.ENGLISH).format(now.time).uppercase()); v.setTextViewText(R.id.date_day, java.text.SimpleDateFormat("EEEE", java.util.Locale.ENGLISH).format(now.time)); m.updateAppWidget(id, v) }
}
class WeatherWidget : BaseWidget() {
    override fun render(c: Context, id: Int, m: AppWidgetManager) { val p = c.getSharedPreferences("widgets", Context.MODE_PRIVATE); val v = RemoteViews(c.packageName, R.layout.widget_weather); v.setTextViewText(R.id.weather_temp, p.getString("temp", "--°") ?: "--°"); v.setTextViewText(R.id.weather_condition, p.getString("condition", "Set location in Widgets") ?: "Set location in Widgets"); v.setTextViewText(R.id.weather_highlow, p.getString("highlow", "↑--°  |  ↓--°") ?: "↑--°  |  ↓--°"); v.setTextViewText(R.id.weather_place, p.getString("place", "Current location") ?: "Current location"); m.updateAppWidget(id, v) }
}

object WeatherData {
    fun fetch(lat: Double, lon: Double, c: Context): String? = try {
        val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min&forecast_days=1&timezone=auto")
        val conn = url.openConnection(); conn.connectTimeout = 8000; conn.readTimeout = 8000
        val j = JSONObject(conn.getInputStream().bufferedReader().use { it.readText() }); val cur = j.getJSONObject("current"); val daily = j.getJSONObject("daily")
        val temp = cur.getDouble("temperature_2m").toInt(); val code = cur.getInt("weather_code"); val cond = condition(code)
        val hi = daily.getJSONArray("temperature_2m_max").getDouble(0).toInt(); val lo = daily.getJSONArray("temperature_2m_min").getDouble(0).toInt()
        val place = "${String.format(java.util.Locale.US, "%.2f", lat)}, ${String.format(java.util.Locale.US, "%.2f", lon)}"
        c.getSharedPreferences("widgets", Context.MODE_PRIVATE).edit().putString("temp", "${temp}°").putString("condition", cond).putString("highlow", "↑${hi}°  |  ↓${lo}°").putString("place", place).apply()
        "Weather updated • $cond, ${temp}°"
    } catch (_: Exception) { null }
    private fun condition(c: Int) = when(c) { 0 -> "Clear"; 1,2 -> "Partly cloudy"; 3 -> "Overcast"; 45,48 -> "Foggy"; in 51..67 -> "Drizzle / Rain"; in 71..77 -> "Snow"; in 80..82 -> "Rain showers"; in 95..99 -> "Thunderstorm"; else -> "Cloudy" }
}
class RefreshWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result { val prefs = applicationContext.getSharedPreferences("widgets", Context.MODE_PRIVATE); val lat = prefs.getString("lat", null)?.toDoubleOrNull(); val lon = prefs.getString("lon", null)?.toDoubleOrNull(); if (lat != null && lon != null) WeatherData.fetch(lat, lon, applicationContext); val m = AppWidgetManager.getInstance(applicationContext); listOf(WeatherWidget::class.java, BatteryGridWidget::class.java, DateWidget::class.java, BatteryBarWidget::class.java, ChargingInfoWidget::class.java).forEach { cl -> m.getAppWidgetIds(android.content.ComponentName(applicationContext, cl)).forEach { id -> val i = Intent(applicationContext, cl).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE).putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, intArrayOf(id)); applicationContext.sendBroadcast(i) } }; return Result.success() }
}
