package com.maddy.widgets

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 40, 28, 24); setBackgroundColor(0xFFF4F5F8.toInt()) }
        root.addView(TextView(this).apply { text = "Widgets"; textSize = 32f; setTextColor(0xFF111827.toInt()); setTypeface(null, 1) })
        root.addView(TextView(this).apply { text = "Your personal home-screen widgets"; textSize = 14f; setTextColor(0xFF667085.toInt()); setPadding(0, 4, 0, 24) })
        status = TextView(this).apply { text = "Weather location not set"; textSize = 15f; setTextColor(0xFF344054.toInt()); setPadding(0, 12, 0, 18) }; root.addView(status)
        root.addView(action("Detect location & update weather") { requestWeatherLocation() })
        root.addView(action("Refresh all widgets") { refreshAll(); status.text = "Widgets refreshed" })
        root.addView(TextView(this).apply { text = "\nADD TO HOME SCREEN\n1. Long-press an empty area on your home screen.\n2. Choose Widgets.\n3. Find ‘Widgets’ and select the design you want.\n4. Drag it onto your home screen.\n\nBattery readings come from Android. Weather needs location permission and internet. The four-circle design is a phone-battery visual, not four separate device sensors."; textSize = 14f; setTextColor(0xFF475467.toInt()); setPadding(0, 24, 0, 0) })
        setContentView(root)
        val req = PeriodicWorkRequestBuilder<RefreshWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("widget_refresh", androidx.work.ExistingPeriodicWorkPolicy.UPDATE, req)
        refreshAll()
    }
    private fun action(label: String, fn: () -> Unit) = Button(this).apply { text = label; isAllCaps = false; setOnClickListener { fn() } }
    private fun requestWeatherLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION), 71); return
        }
        readLocation()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) { super.onRequestPermissionsResult(requestCode, permissions, grantResults); if (requestCode == 71 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) readLocation() else status.text = "Location permission not granted" }
    private fun readLocation() {
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            val providers = lm.getProviders(true)
            val loc: Location? = providers.mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (_: SecurityException) { null } }.maxByOrNull { it.time }
            if (loc == null) { status.text = "Location unavailable. Turn on device location and try again."; return }
            getSharedPreferences("widgets", MODE_PRIVATE).edit().putString("lat", loc.latitude.toString()).putString("lon", loc.longitude.toString()).apply()
            Thread { val result = WeatherData.fetch(loc.latitude, loc.longitude, this); runOnUiThread { status.text = result ?: "Location saved; weather will refresh when data is available."; refreshAll() } }.start()
        } catch (_: Exception) { status.text = "Could not read location" }
    }
    private fun refreshAll() {
        val manager = AppWidgetManager.getInstance(this)
        listOf(WeatherWidget::class.java, BatteryGridWidget::class.java, DateWidget::class.java, BatteryBarWidget::class.java, ChargingInfoWidget::class.java).forEach { c ->
            val ids = manager.getAppWidgetIds(ComponentName(this, c)); if (ids.isNotEmpty()) { val i = Intent(this, c).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE).putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids); sendBroadcast(i) }
        }
    }
}
