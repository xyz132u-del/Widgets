# Widgets — Android project

A native Android starter project containing five home-screen App Widgets inspired by the supplied references:

1. Blue weather card
2. Four-indicator battery panel
3. Date / weekday pill
4. Green battery percentage bar
5. Black charging information card

## Build

Open this folder in Android Studio (Ladybug or newer), allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s). The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35, and minimum Android 8.0 (API 26). Android Studio may install the required SDK automatically.

## Install and use

Install the generated APK. Open **Widgets**, tap **Detect location & update weather**, and grant approximate or precise location permission. Then long-press the Android home screen, open **Widgets**, find **Widgets**, and drag any of the five designs onto the home screen. Use the app's refresh button to refresh all installed widgets.

## Important implementation notes

- Battery percentage and charging/not-charging status are read from Android's sticky battery broadcast. Power connect/disconnect events refresh the battery widgets; WorkManager also refreshes widgets periodically (Android may defer background work to save power).
- Android does not expose arbitrary Bluetooth accessory battery levels through one universal API. In the four-indicator panel, only the phone value is real; the other three values show dashes until device-specific Bluetooth integrations are added. They are deliberately not fabricated.
- Charging time-to-full is not reliably exposed by all Android devices. The black card therefore reports when charging is active but displays that an ETA is unavailable rather than inventing a time.
- Weather uses Open-Meteo and the last-known device location. It requires internet and location permission. The displayed location currently uses coordinates; reverse-geocoding into a locality name can be added separately. Refreshing weather happens when the app opens / location is updated and during periodic background refresh.
- The supplied images are low-resolution references. Layouts use the same general geometry, colors, labels and visual hierarchy, but exact pixel matching needs sharper reference images and device-specific preview iterations.
